//
//  KisiDetayInteractor.swift
//  KisilerUygulamasi
//
//  Created by Kasım on 9.10.2022.
//

import Foundation

class KisiDetayInteractor : PresenterToInteractorKisiDetayProtocol {
    func kisiGuncelle(kisi:KisilerModel, kisi_ad: String, kisi_tel: String) {
        
    }
}
