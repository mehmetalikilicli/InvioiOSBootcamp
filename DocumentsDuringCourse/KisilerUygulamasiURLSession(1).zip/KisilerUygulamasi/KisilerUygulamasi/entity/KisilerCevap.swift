//
//  KisilerCevap.swift
//  KisilerUygulamasi
//
//  Created by Kasım on 11.10.2022.
//

import Foundation

class KisilerCevap : Codable {
    var kisiler:[Kisiler]?
    var success:Int?
}
