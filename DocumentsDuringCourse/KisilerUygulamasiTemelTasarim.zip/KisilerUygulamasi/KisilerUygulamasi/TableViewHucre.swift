//
//  TableViewHucre.swift
//  KisilerUygulamasi
//
//  Created by Mehmet Ali Kılıçlı on 4.10.2022.
//

import UIKit

class TableViewHucre: UITableViewCell {
    
    
    @IBOutlet weak var kisiBilgiLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
