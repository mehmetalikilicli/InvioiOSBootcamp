//
//  Router.swift
//  ViperKullanimi
//
//  Created by Kasım on 6.10.2022.
//

import Foundation

class Router : PresenterToRouterProtocol {
    static func createModule(ref: ViewController) {
        let presenter = Presenter()
        
        //View katmanı değişkeni
        ref.presenterNesnesi = presenter
        
        //Presenter katmanı değişkeni
        ref.presenterNesnesi?.interactor = Interactor()
        ref.presenterNesnesi?.view = ref
        
        //Interactor katmanı değişkeni
        ref.presenterNesnesi?.interactor?.presenter = presenter
    }
}
